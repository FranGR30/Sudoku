from sudoku import iniciar

# punto de inicio del programa
iniciar()
